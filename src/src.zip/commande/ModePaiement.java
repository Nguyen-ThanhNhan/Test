package commande;

public enum ModePaiement {
	CB, espece, cheque, virementBancaire;
}
