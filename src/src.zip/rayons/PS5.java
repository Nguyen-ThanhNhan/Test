package rayons;

public class PS5 extends Produit {
	
	public PS5() {
		super("PS5", 455.45);
		super.setDetails("La PlayStation 5 (abr�g�e officiellement PS5) est la console de jeux vid�o \n" 
				+ "de salon de neuvi�me g�n�ration d�velopp�e par Sony Interactive Entertainment. \n" 
				+ "Elle est commercialis�e le 12 novembre 2020 aux �tats-Unis, au Canada, en Australie et au Japon, \n"
				+ "puis le 19 novembre en Europe et dans le reste du monde. Elle succ�de � la PlayStation 4 \n" 
				+ "et se place en concurrence avec les Xbox Series de Microsoft et la Nintendo Switch de Nintendo.");
	}

}
