package rayons;

public class Sweat extends Produit {
	
	public Sweat() {
		super("Sweat", 40.00);
		super.setDetails("Sweat de la promo 2�me ann�e de DUT Informatique � 40�");
	}

}
