package rayons;

public class Livre extends Produit {
	
	public Livre(String details) {
		super("Livre", 35);
		super.setDetails(details);
	}

}
