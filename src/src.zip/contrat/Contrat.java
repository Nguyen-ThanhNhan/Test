package contrat;

public interface Contrat {

	//Selon son type de contrat, le vendeur gagnera un pourcentage du prixTotal d'une commande
	public int pourcentageDeGain();
	
}
